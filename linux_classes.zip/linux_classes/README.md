# Files

Source files in this exercise are part of source code from `angular` framework repository.

All rights reserved to the creators and contributors.

## Full source code
For check the full source code please visit [https://github.com/angular/angular](https://github.com/angular/angular)